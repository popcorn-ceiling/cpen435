Compile: 
    $ mpicc -o lab4 lab4.c -Wextra

Run:
    $ lab4.sh

Log file:
    <job_id>.log
    cat *.log > out.log
