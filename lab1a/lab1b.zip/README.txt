Compile lab1b:
$ gcc -o lab1b lab1b.c -lpthread
