/* filename: lab1b.c
 * author: daniel collins (dcollins3@zagmail.gonzaga.edu)
 * date: 2/20/15
 * brief: matrix-matrix multiplication with pthreads
 */

#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <time.h>

/* holds all per thread values */
typedef struct args_struct
{
    int id;
    int size;
    int row_index;
    int num_rows;
    double *matrix_a;
    double *matrix_b;
    double *matrix_c;
} matrix_args;

/* assumes one dimmensional array nxn matrix format of type double */
void matrix_print(double *matrix, int size)
{
    int i, j;
    for (i = 0; i < size; i++)
    {   
        printf("[ ");
        for (j = 0; j < size; j++)
        {
            if (j != size - 1)
            {
                printf("%3.1f ", matrix[i*size + j]);
            } else {
                printf("%3.1f ]\n", matrix[i*size + j]);
            }
        }
    }
}

/* assumes one dimmensional array nxn matrix format of type double */
void matrix_init(double *matrix, int size)
{
    int i, j;
    for (i = 0; i < size; i++)
    {
        for (j = 0; j < size; j++)
        {
            /* arbitrarily limited to 0 - 49 */
            matrix[i*size + j] = (rand() % 50);
        }
    }
}

/* this function may be prone to false sharing 
 * shouldn't be any data contention though since 
 * each thread has it's own set of rows 
 */
void *matrix_mult(void *arguments)
{
    int i, j, k, n;
    int end_row;
    matrix_args *args = (matrix_args*) arguments;
    end_row = args->row_index + args->num_rows;
    n = args->size;
    
    for (i = args->row_index; i < end_row; i++)
    {
        for (j = 0; j < n; j++)
        {
            for (k = 0; k < n; k++)
            {
                args->matrix_c[i*n + j] += \
                    args->matrix_a[i*n + k] * args->matrix_b[k*n + j];
            }
        }
    }

    /* every thread frees it's own arguments */
    free(arguments);
    arguments = NULL;
    args = NULL;
    pthread_exit(NULL);
}

int main(int argc, char *argv[])
{
    if (3 > argc)
    {
        printf("lab1b usage: ./lab1b n nthreads\n");
        exit(-1);
    }
    const int n = atoi(argv[1]);
    const int nthd = atoi(argv[2]);
    int rows_per_thd;
    int extra_rows;
    int rc, i;
    pthread_t threads[nthd];

    printf("Matrix dimmension: %d  Number of threads: %d\n", n, nthd);
    
    /* allocate matrices */
    double *matrix_a = malloc(n*n * sizeof *matrix_a);
    double *matrix_b = malloc(n*n * sizeof *matrix_b);
    double *matrix_c = calloc(n*n,  sizeof *matrix_c);
    if (matrix_a == NULL || matrix_b == NULL || matrix_c == NULL)
    {
        printf("Uh oh, a matrix didn't get allocated. Exiting.\n");
        exit(1);
    }

    /* allocate array of struct pointers for args */
    matrix_args **args = malloc(nthd * sizeof(matrix_args));

    /* allocate argument struct for each thread */
    for (i = 0; i < nthd; i++)
    {
        /* freed in mult_matrix */
        args[i] = malloc(sizeof(matrix_args));
        if (args[i] == NULL)
        {
            printf("Uh oh, matrix args didn't get allocated. Exiting.\n");
            exit(1);
        }
        /* initialize some values */
        args[i]->size = n;
        args[i]->matrix_a = matrix_a;
        args[i]->matrix_b = matrix_b;
        args[i]->matrix_c = matrix_c;
    }

    /* initialize matrices */
    srand(time(NULL));
    matrix_init(matrix_a, n);
    matrix_init(matrix_b, n);

    /* extra rows will be given to the last thread spawned */
    rows_per_thd = n / nthd;
    extra_rows = n % nthd;

    /* do actual work in the threads */
    for(i = 0; i < nthd; i++)
    {
        args[i]->id = i;
        args[i]->row_index = i * rows_per_thd;
        args[i]->num_rows = rows_per_thd + ((i == nthd-1) ? extra_rows : 0);
        rc = pthread_create(&threads[i], NULL, matrix_mult, (void *)args[i]);
        if (rc)
        {
            printf("ERROR: return code from pthread_create() is %d\n", rc);
            exit(-1);
        }
    }

    for(i = 0; i < nthd; i++)
    {
        rc = pthread_join(threads[i], NULL);
        if (rc)
        {
            printf("ERROR: return code from pthread_join() is %d\n", rc);
            exit(-1);
        }
    }

    /* display results */
    if (n <= 40)
    {
        printf("Matrix A\n");
        matrix_print(matrix_a, n);
        printf("Matrix B\n");
        matrix_print(matrix_b, n);
        printf("Matrix C\n");
        matrix_print(matrix_c, n);
    } else {
        printf ("Matrix C > 40x40, will not print\n");
    }

    /* cleanup */
    free(args);
    free(matrix_a);
    free(matrix_b);
    free(matrix_c);
    args = NULL;
    matrix_a = NULL;
    matrix_b = NULL;
    matrix_c = NULL;
    
    return 0;
} 
